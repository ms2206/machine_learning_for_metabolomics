# skin cancer > skin cancer dataset
https://universe.roboflow.com/university-zrioj/skin-cancer-xv3k6

Provided by a Roboflow user
License: CC BY 4.0

